import { useState, useRef, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ContentArea } from './components/ContentArea';
import { RightSidebar } from './components/RightSidebar';
import { Dashboard } from './components/Dashboard';
import { TopicsBar } from './components/TopicsBar';
import { ThemeProvider } from './components/ThemeProvider';

function AppContent() {
  // 🔹 BACKEND DATA STATE
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // 🔹 UI STATES
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [selectedSubTopicId, setSelectedSubTopicId] = useState<string | null>(null);
  const [selectedTopicId, setSelectedTopicId] = useState<string | null>(null);
  const [difficulty, setDifficulty] = useState<'beginner' | 'intermediate' | 'expert'>('beginner');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [voiceGender, setVoiceGender] = useState<'male' | 'female'>('female');
  const [leftSidebarMinimized, setLeftSidebarMinimized] = useState(false);
  const [rightSidebarMinimized, setRightSidebarMinimized] = useState(false);

  const contentRef = useRef<HTMLDivElement>(null);
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance | null>(null);

  // ==============================
  // 🔹 FETCH COURSES FROM SPRING BOOT
  // ==============================
  useEffect(() => {
    fetch('http://localhost:8080/api/courses')
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch courses');
        return res.json();
      })
      .then(data => {
        setCourses(data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  // ==============================
  // 🔹 SELECTED COURSE / TOPIC LOGIC
  // ==============================
  const selectedCourse = selectedCourseId
    ? courses.find(c => c.id === selectedCourseId) || null
    : null;

  const selectedSubTopic =
    selectedCourse && selectedSubTopicId
      ? selectedCourse.subTopics.find((st: any) => st.id === selectedSubTopicId) || null
      : null;

  const selectedTopic =
    selectedSubTopic && selectedTopicId
      ? selectedSubTopic.topics.find((t: any) => t.id === selectedTopicId) || null
      : null;

  const topicsList = selectedSubTopic ? selectedSubTopic.topics : [];

  const currentTopicIndex = topicsList.findIndex(
    (t: any) => t.id === selectedTopicId
  );

  const prevTopicName =
    currentTopicIndex > 0 ? topicsList[currentTopicIndex - 1].name : undefined;

  const nextTopicName =
    currentTopicIndex < topicsList.length - 1
      ? topicsList[currentTopicIndex + 1].name
      : undefined;

  // ==============================
  // 🔹 TEXT TO SPEECH
  // ==============================
  const toggleSpeech = () => {
    if (!contentRef.current) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textContent = contentRef.current.innerText;
    const utterance = new SpeechSynthesisUtterance(textContent);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 1;

    const voices = window.speechSynthesis.getVoices();
    const selectedVoice = voices.find(v =>
      voiceGender === 'female'
        ? !v.name.toLowerCase().includes('male')
        : v.name.toLowerCase().includes('male')
    );

    if (selectedVoice) utterance.voice = selectedVoice;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    speechSynthesisRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  useEffect(() => {
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, [selectedTopicId, difficulty]);

  // ==============================
  // 🔹 HANDLERS
  // ==============================
  const handleCourseSelect = (courseId: string) => {
    setSelectedCourseId(courseId);
    setSelectedSubTopicId(null);
    setSelectedTopicId(null);
    setDifficulty('beginner');
  };

  const handleSubTopicSelect = (subTopicId: string) => {
    setSelectedSubTopicId(subTopicId);
    setSelectedTopicId(null);
    setDifficulty('beginner');
  };

  const handleTopicSelect = (topicId: string) => {
    let parentCourseId: string | null = null;
    let parentSubTopicId: string | null = null;

    for (const course of courses) {
      for (const subTopic of course.subTopics) {
        if (subTopic.topics.some((t: any) => t.id === topicId)) {
          parentCourseId = course.id;
          parentSubTopicId = subTopic.id;
          break;
        }
      }
      if (parentCourseId) break;
    }

    if (parentCourseId) setSelectedCourseId(parentCourseId);
    if (parentSubTopicId) setSelectedSubTopicId(parentSubTopicId);

    setSelectedTopicId(topicId);
    setDifficulty('beginner');

    setTimeout(() => {
      contentRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handlePrevTopic = () => {
    if (currentTopicIndex > 0) {
      handleTopicSelect(topicsList[currentTopicIndex - 1].id);
    }
  };

  const handleNextTopic = () => {
    if (currentTopicIndex < topicsList.length - 1) {
      handleTopicSelect(topicsList[currentTopicIndex + 1].id);
    }
  };

  const handleDifficultyChange = (d: 'beginner' | 'intermediate' | 'expert') => {
    setDifficulty(d);
    setTimeout(() => {
      contentRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const filteredCourses = searchQuery
    ? courses.filter(course =>
        course.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.subTopics.some((st: any) =>
          st.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          st.topics.some((t: any) =>
            t.name.toLowerCase().includes(searchQuery.toLowerCase())
          )
        )
      )
    : courses;

  const showDashboard = !selectedCourseId;

  // ==============================
  // 🔹 LOADING & ERROR
  // ==============================
  if (loading) return <div className="p-6">Loading courses...</div>;
  if (error) return <div className="p-6 text-red-500">{error}</div>;

  // ==============================
  // 🔹 UI RENDER
  // ==============================
  return (
    <div className="h-screen flex flex-col bg-gray-100 dark:bg-gray-900">
      <Header
        onToggleSpeech={toggleSpeech}
        isSpeaking={isSpeaking}
        onSearch={handleSearch}
        voiceGender={voiceGender}
        onVoiceChange={setVoiceGender}
      />

      {!showDashboard && (
        <TopicsBar
          courses={filteredCourses}
          onCourseSelect={handleCourseSelect}
          selectedCourseId={selectedCourseId}
        />
      )}

      <div className="flex flex-1 overflow-hidden">
        {!showDashboard && (
          <Sidebar
            courses={filteredCourses}
            selectedCourse={selectedCourseId}
            selectedSubTopic={selectedSubTopicId}
            selectedTopic={selectedTopicId}
            onCourseSelect={handleCourseSelect}
            onSubTopicSelect={handleSubTopicSelect}
            onTopicSelect={handleTopicSelect}
            searchQuery={searchQuery}
            isMinimized={leftSidebarMinimized}
            onToggleMinimize={() => setLeftSidebarMinimized(!leftSidebarMinimized)}
          />
        )}

        {showDashboard ? (
          <Dashboard onCourseSelect={handleCourseSelect} />
        ) : (
          <ContentArea
            course={selectedCourse}
            topic={selectedTopic}
            difficulty={difficulty}
            onDifficultyChange={handleDifficultyChange}
            contentRef={contentRef}
            onPrevTopic={handlePrevTopic}
            onNextTopic={handleNextTopic}
            hasPrev={currentTopicIndex > 0}
            hasNext={currentTopicIndex < topicsList.length - 1}
            prevTopicName={prevTopicName}
            nextTopicName={nextTopicName}
          />
        )}

        {!showDashboard && (
          <RightSidebar
            course={selectedCourse}
            isMinimized={rightSidebarMinimized}
            onToggleMinimize={() => setRightSidebarMinimized(!rightSidebarMinimized)}
          />
        )}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}
